"use strict"
let primaryNav = document.querySelector('#bg-navbar');
window.onscroll = function(){
	let scrollNav = window.scrollY;
	if(scrollNav >= 200){
		primaryNav.classList.add('after-scroll-nav')
	}else{
		primaryNav.classList.remove('after-scroll-nav')
	}
}